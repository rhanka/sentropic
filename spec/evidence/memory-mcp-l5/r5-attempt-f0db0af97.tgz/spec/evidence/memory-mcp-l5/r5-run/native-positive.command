make memory-l5-native-positive MEMORY_L5_REPORT=/workspace/spec/evidence/memory-mcp-l5/r5-run/native-positive.json API_PORT=9625 UI_PORT=5825 MAILDEV_UI_PORT=1725 ENV=test-memory-l5

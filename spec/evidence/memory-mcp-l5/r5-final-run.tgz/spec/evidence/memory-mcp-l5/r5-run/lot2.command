make memory-l5-test LOT=2 ARTIFACT_MANIFEST=tools/memory-mcp-l5/artifacts/lot2-manifest.json API_PORT=9625 UI_PORT=5825 MAILDEV_UI_PORT=1725 ENV=test-memory-l5

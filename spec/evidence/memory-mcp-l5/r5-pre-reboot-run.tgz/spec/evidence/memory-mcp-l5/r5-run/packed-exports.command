make memory-l5-packed SCOPE=packed/exports.test.ts ARTIFACT_MANIFEST=tools/memory-mcp-l5/artifacts/candidate-manifest.json API_PORT=9625 UI_PORT=5825 MAILDEV_UI_PORT=1725 ENV=test-memory-l5

---
name: engram
description: "any input (code, docs, papers, images) -> knowledge graph -> clustered communities -> static Ontology Studio + JSON + audit report. Use when user asks any question about a codebase, project content, architecture, or file relationships, especially if .engram/ exists. Provides persistent graph with god nodes, community detection, and BFS/DFS query tools."
trigger: /engram
---

# /engram

> Alias: `/graphify` still triggers this skill (deprecated alias for `/engram`).

Turn any folder of files into a navigable knowledge graph with community detection, a verifiable audit trail, and three outputs: a static Ontology Studio, GraphRAG-ready JSON, and a plain-language GRAPH_REPORT.md.

## Usage

```
/engram                                             # full pipeline on current directory → Obsidian vault
/engram <path>                                      # full pipeline on specific path
/engram <path> --mode deep                          # thorough extraction, richer INFERRED edges
/engram <path> --pdf-ocr auto                       # preflight PDFs; OCR scanned/low-text PDFs with mistral-ocr when needed
/engram <path> --update                             # incremental - re-extract only new/changed files
/engram <path> --cluster-only                       # rerun clustering on existing graph
engram studio export .engram/studio               # build the self-contained static Ontology Studio (open by serving it with any static file server)
/engram <path> --svg                                # also export graph.svg (embeds in Notion, GitHub)
/engram <path> --graphml                            # export graph.graphml (Gephi, yEd)
/engram <path> --neo4j                              # generate .engram/cypher.txt for Neo4j
/engram <path> --neo4j-push bolt://localhost:7687   # push directly to Neo4j
/engram <path> --mcp                                # start MCP stdio server for agent access
/engram <path> --watch                              # watch folder, auto-rebuild on code changes (no LLM needed)
engram wiki describe --graph .engram/graph.json --mode assistant --targets all  # opt-in description sidecars
engram export wiki --graph .engram/graph.json --descriptions .engram/wiki/descriptions.json
engram export obsidian --graph .engram/graph.json --descriptions .engram/wiki/descriptions.json
/engram add <url>                                   # fetch URL, save to ./raw, update graph
/engram add <url> --author "Name"                   # tag who wrote it
/engram add <url> --contributor "Name"              # tag who added it to the corpus
/engram migrate-state --dry-run                    # plan graphify-out -> .engram migration
/engram query "<question>"                          # BFS traversal - broad context
/engram query "<question>" --dfs                    # DFS - trace a specific path
/engram query "<question>" --budget 1500            # cap answer at N tokens
/engram summary --graph .engram/graph.json        # compact first-hop orientation before deep traversal
/engram minimal-context --task "review PR" --graph .engram/graph.json  # first review call
/engram review-delta --files src/auth.ts --graph .engram/graph.json  # review impact for changed files
/engram review-analysis --files src/auth.ts --graph .engram/graph.json  # blast radius + review views
/engram recommend-commits --files src/auth.ts,src/session.ts --graph .engram/graph.json  # advisory commit grouping
/engram path "AuthModule" "Database"                # shortest path between two concepts
/engram explain "SwinTransformer"                   # plain-language explanation of a node
```

## What engram is for

Engram is built around Andrej Karpathy's /raw folder workflow: drop anything into a folder - papers, tweets, screenshots, code, notes - and get a structured knowledge graph that shows you what you didn't know was connected.

Three things it does that Claude alone cannot:
1. **Persistent graph** - relationships are stored in `.engram/graph.json` and survive across sessions. Ask questions weeks later without re-reading everything.
2. **Verifiable audit trail** - every edge is tagged EXTRACTED, INFERRED, or AMBIGUOUS. You know what was found vs invented.
3. **Cross-document surprise** - community detection finds connections between concepts in different files that you would never think to ask about directly.

Use it for:
- A codebase you're new to (understand architecture before touching anything)
- A reading list (papers + tweets + notes → one navigable graph)
- A research corpus (citation graph + concept graph in one)
- Your personal /raw folder (drop everything in, let it grow, query it)

## What You Must Do When Invoked

If no path was given, use `.` (current directory). Do not ask the user for a path.

Follow these steps in order. Do not skip steps.

### Step 1 - Ensure engram is installed

```bash
command -v engram >/dev/null 2>&1 || command -v graphify >/dev/null 2>&1 || npm install -g @sentropic/engram 2>&1 | tail -3
mkdir -p .engram
```

If this step prints `ERROR: Graph is empty`, stop and tell the user what happened - do not proceed to labeling or visualization.

Replace INPUT_PATH with the actual path.

### Step 5 - Label communities and enrich

**Enrichment commands (no API key needed; opt-in, non-destructive).** On a built or curated `graph.json` you can stamp enrichment in place without re-extracting: `engram describe .` (node descriptions), `engram label .` (community labels), and `engram cite .` (grounded citations). `engram cite` (alias `ground-citations`) scans the corpus and grounds per-entity `node.citations[]` entries `{quote, source_file, source_location}` — populating **new** verbatim citations, not just projecting existing ones. **Heuristic mode is the no-key DEFAULT** (`--mode heuristic|assistant|api`); it is **anti-hallucination** — every emitted `quote` is a verified verbatim substring of the source, and any quote that cannot be relocated is dropped, never invented. It UNIONS with existing citations (never clobbers). Symmetric to `describe`/`label` and, like them, **opt-in** (NOT auto-run). **Run `engram cite .` BEFORE the studio/wiki export** so entity panels ship non-null citations.

```bash
engram cite .                 # no-key heuristic grounding (default)
engram cite . --only-missing  # additive pass: only nodes with no citations yet
engram cite . --dry-run       # report coverage without writing
```

Read `.engram/.graphify_analysis.json`. For each community key, look at its node labels and write a 2-5 word plain-language name (e.g. "Attention Mechanism", "Training Pipeline", "Data Loading").

Then regenerate the report and save the labels for the visualizer:

```bash
node -e "
const fs = require('fs');
const { buildFromJson } = require('@sentropic/engram');
const { scoreAll } = require('@sentropic/engram');
const { godNodes, surprisingConnections, suggestQuestions } = require('@sentropic/engram');
const { generateReport } = require('@sentropic/engram');

const extraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const detection = JSON.parse(fs.readFileSync('.engram/.graphify_detect.json', 'utf-8'));
const analysis = JSON.parse(fs.readFileSync('.engram/.graphify_analysis.json', 'utf-8'));

const G = buildFromJson(extraction);
const communities = Object.fromEntries(Object.entries(analysis.communities).map(([k, v]) => [Number(k), v]));
const cohesion = Object.fromEntries(Object.entries(analysis.cohesion).map(([k, v]) => [Number(k), v]));
const tokens = {input: extraction.input_tokens || 0, output: extraction.output_tokens || 0};

// LABELS - replace these with the names you chose above
const labels = LABELS_DICT;

const questions = suggestQuestions(G, communities, labels);

const report = generateReport(G, communities, cohesion, labels, analysis.gods, analysis.surprises, detection, tokens, '.', {suggestedQuestions: questions});
fs.writeFileSync('.engram/GRAPH_REPORT.md', report);
fs.writeFileSync('.engram/.graphify_labels.json', JSON.stringify(Object.fromEntries(Object.entries(labels).map(([k, v]) => [String(k), v]))));
console.log('Report updated with community labels');
"
```

Replace `LABELS_DICT` with the actual dict you constructed (e.g. `{0: "Attention Mechanism", 1: "Training Pipeline"}`).
Replace INPUT_PATH with the actual path.

### Step 6 - Generate Obsidian vault (opt-in) + static Ontology Studio

**Generate the static Ontology Studio always.** **Obsidian vault only if `--obsidian` was explicitly given** — skip it otherwise, it generates one file per node.

Wiki descriptions are opt-in and two-step. First generate sidecars, then pass their index into wiki or Obsidian rendering:

```bash
engram wiki describe --graph .engram/graph.json --mode assistant --targets all
# or, for direct mode:
engram wiki describe --graph .engram/graph.json --mode direct --backend openai --targets all

engram export wiki --graph .engram/graph.json --descriptions .engram/wiki/descriptions.json
engram export obsidian --graph .engram/graph.json --descriptions .engram/wiki/descriptions.json
```

Sidecars live under `.engram/wiki/descriptions/` with an index at `.engram/wiki/descriptions.json`. They record graph hash, prompt/generator provenance, evidence refs, and cache keys; existing generated sidecars may be reused when a fresh generation does not complete. `insufficient_evidence` sidecars render no Description section. This never mutates `.engram/graph.json`.

If `--obsidian` was given:

```bash
node -e "
const fs = require('fs');
const { buildFromJson } = require('@sentropic/engram');
const { toWiki, toCanvas } = require('@sentropic/engram');

const extraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const analysis = JSON.parse(fs.readFileSync('.engram/.graphify_analysis.json', 'utf-8'));
const labelsRaw = fs.existsSync('.engram/.graphify_labels.json') ? JSON.parse(fs.readFileSync('.engram/.graphify_labels.json', 'utf-8')) : {};

const G = buildFromJson(extraction);
const communities = Object.fromEntries(Object.entries(analysis.communities).map(([k, v]) => [Number(k), v]));
const cohesion = Object.fromEntries(Object.entries(analysis.cohesion).map(([k, v]) => [Number(k), v]));
const labels = Object.fromEntries(Object.entries(labelsRaw).map(([k, v]) => [Number(k), v]));

const n = toWiki(G, communities, '.engram/obsidian', {communityLabels: Object.keys(labels).length ? labels : undefined, cohesion});
console.log(\`Obsidian vault: ${n} notes in .engram/obsidian/\`);

toCanvas(G, communities, '.engram/obsidian/graph.canvas', {communityLabels: Object.keys(labels).length ? labels : undefined});
console.log('Canvas: .engram/obsidian/graph.canvas - open in Obsidian for structured community layout');
console.log();
console.log('Open .engram/obsidian/ as a vault in Obsidian.');
console.log('  Graph view   - nodes colored by community (set automatically)');
console.log('  graph.canvas - structured layout with communities as groups');
console.log('  _COMMUNITY_* - overview notes with cohesion scores and dataview queries');
"
```

Generate the static Ontology Studio (always). It bundles the prebuilt studio SPA (`index.html` + `assets/`) with the data artifacts the SPA reads next to it — `graph.json`, `scene.json` (with pre-computed force-layout positions), `entities.json`, `reconciliation-candidates.json`, and `class-hierarchies.json` (the latter only when a profile carries a `class_hierarchies` block):

```bash
# Default state dir is .engram; pass --profile <path> to emit class-hierarchies.json for ontology profiles
engram studio export .engram/studio
```

The studio scales to large graphs (WebGL render + pre-computed positions), so there is no node-count cap — even oversized graphs export to the studio. To open it, serve the export dir (`.engram/studio`) with any static file server and load `index.html` in a browser.

### Step 7 - Neo4j export (only if --neo4j or --neo4j-push flag)

**If `--neo4j`** - generate a Cypher file for manual import:

```bash
node -e "
const fs = require('fs');
const { buildFromJson, toCypher } = require('@sentropic/engram');

const G = buildFromJson(JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8')));
toCypher(G, '.engram/cypher.txt');
console.log('cypher.txt written - import with: cypher-shell < .engram/cypher.txt');
"
```

**If `--neo4j-push <uri>`** - push directly to a running Neo4j instance. Ask the user for credentials if not provided:

```bash
node -e "
const fs = require('fs');
const { buildFromJson, pushToNeo4j } = require('@sentropic/engram');

const extraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const analysis = JSON.parse(fs.readFileSync('.engram/.graphify_analysis.json', 'utf-8'));
const G = buildFromJson(extraction);
const communities = Object.fromEntries(Object.entries(analysis.communities).map(([k, v]) => [Number(k), v]));

const result = pushToNeo4j(G, {uri: 'NEO4J_URI', user: 'NEO4J_USER', password: 'NEO4J_PASSWORD', communities});
console.log(\`Pushed to Neo4j: ${result.nodes} nodes, ${result.edges} edges\`);
"
```

Replace `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD` with actual values. Default URI is `bolt://localhost:7687`, default user is `neo4j`. Uses MERGE - safe to re-run without creating duplicates.

### Step 7b - SVG export (only if --svg flag)

```bash
node -e "
const fs = require('fs');
const { buildFromJson, toSvg } = require('@sentropic/engram');

const extraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const analysis = JSON.parse(fs.readFileSync('.engram/.graphify_analysis.json', 'utf-8'));
const labelsRaw = fs.existsSync('.engram/.graphify_labels.json') ? JSON.parse(fs.readFileSync('.engram/.graphify_labels.json', 'utf-8')) : {};

const G = buildFromJson(extraction);
const communities = Object.fromEntries(Object.entries(analysis.communities).map(([k, v]) => [Number(k), v]));
const labels = Object.fromEntries(Object.entries(labelsRaw).map(([k, v]) => [Number(k), v]));

toSvg(G, communities, '.engram/graph.svg', {communityLabels: Object.keys(labels).length ? labels : undefined});
console.log('graph.svg written - embeds in Obsidian, Notion, GitHub READMEs');
"
```

### Step 7c - GraphML export (only if --graphml flag)

```bash
node -e "
const fs = require('fs');
const { buildFromJson, toGraphml } = require('@sentropic/engram');

const extraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const analysis = JSON.parse(fs.readFileSync('.engram/.graphify_analysis.json', 'utf-8'));

const G = buildFromJson(extraction);
const communities = Object.fromEntries(Object.entries(analysis.communities).map(([k, v]) => [Number(k), v]));

toGraphml(G, communities, '.engram/graph.graphml');
console.log('graph.graphml written - open in Gephi, yEd, or any GraphML tool');
"
```

### Step 7d - MCP server (only if --mcp flag)

```bash
npx engram serve .engram/graph.json
```

This starts a stdio MCP server that exposes tools: `query_graph`, `get_node`, `get_neighbors`, `get_community`, `god_nodes`, `graph_stats`, `shortest_path`. Add to Claude Desktop or any MCP-compatible agent orchestrator so other agents can query the graph live.

To configure in Claude Desktop, add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "engram": {
      "command": "npx",
      "args": ["engram", "serve", "/absolute/path/to/.engram/graph.json"]
    }
  }
}
```

### Step 8 - Token reduction benchmark (only if total_words > 5000)

If `total_words` from `.engram/.graphify_detect.json` is greater than 5,000, run:

```bash
node -e "
const fs = require('fs');
const { runBenchmark, printBenchmark } = require('@sentropic/engram');

const detection = JSON.parse(fs.readFileSync('.engram/.graphify_detect.json', 'utf-8'));
const result = runBenchmark('.engram/graph.json', {corpusWords: detection.total_words});
printBenchmark(result);
"
```

Print the output directly in chat. If `total_words <= 5000`, skip silently - the graph value is structural clarity, not token compression, for small corpora.

---

### Step 9 - Save manifest, update cost tracker, clean up, and report

```bash
node -e "
const fs = require('fs');
const { saveManifest } = require('@sentropic/engram');

const detect = JSON.parse(fs.readFileSync('.engram/.graphify_detect.json', 'utf-8'));
saveManifest(detect.files);

const extract = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const inputTok = extract.input_tokens || 0;
const outputTok = extract.output_tokens || 0;

const costPath = '.engram/cost.json';
const cost = fs.existsSync(costPath) ? JSON.parse(fs.readFileSync(costPath, 'utf-8')) : {runs: [], total_input_tokens: 0, total_output_tokens: 0};

cost.runs.push({
    date: new Date().toISOString(),
    input_tokens: inputTok,
    output_tokens: outputTok,
    files: detect.total_files || 0,
});
cost.total_input_tokens += inputTok;
cost.total_output_tokens += outputTok;
fs.writeFileSync(costPath, JSON.stringify(cost, null, 2));

console.log(\`This run: \${inputTok.toLocaleString()} input tokens, \${outputTok.toLocaleString()} output tokens\`);
console.log(\`All time: \${cost.total_input_tokens.toLocaleString()} input, \${cost.total_output_tokens.toLocaleString()} output (\${cost.runs.length} runs)\`);
"
rm -f .engram/.graphify_detect.json .engram/.graphify_extract.json .engram/.graphify_ast.json .engram/.graphify_semantic.json .engram/.graphify_analysis.json
rm -f .engram/needs_update 2>/dev/null || true
```

Tell the user (omit the obsidian line unless --obsidian was given):
```
Graph complete. Outputs in PATH_TO_DIR/.engram/

  studio/               - static Ontology Studio, serve with any static file server and open index.html
  GRAPH_REPORT.md       - audit report
  graph.json            - raw graph data
  obsidian/             - Obsidian vault (only if --obsidian was given)
```

Replace PATH_TO_DIR with the actual absolute path of the directory that was processed.

Then paste these sections from GRAPH_REPORT.md directly into the chat:
- God Nodes
- Surprising Connections
- Suggested Questions

Do NOT paste the full report - just those three sections. Keep it concise.

Then immediately offer to explore. Pick the single most interesting suggested question from the report - the one that crosses the most community boundaries or has the most surprising bridge node - and ask:

> "The most interesting question this graph can answer: **[question]**. Want me to trace it?"

If the user says yes, run `/engram query "[question]"` on the graph and walk them through the answer using the graph structure - which nodes connect, which community boundaries get crossed, what the path reveals. Keep going as long as they want to explore. Each answer should end with a natural follow-up ("this connects to X - want to go deeper?") so the session feels like navigation, not a one-shot report.

The graph is the map. Your job after the pipeline is to be the guide.

---

## For --update (incremental re-extraction)

Use when you've added or modified files since the last run. Only re-extracts changed files - saves tokens and time.

```bash
node -e "
const fs = require('fs');
const { detectIncremental } = require('@sentropic/engram');

const result = detectIncremental('INPUT_PATH');
const newTotal = result.new_total || 0;
console.log(JSON.stringify(result, null, 2));
fs.writeFileSync('.engram/.graphify_incremental.json', JSON.stringify(result));
if (newTotal === 0) {
    console.log('No files changed since last run. Nothing to update.');
    process.exit(0);
}
console.log(\`${newTotal} new/changed file(s) to re-extract.\`);
"
```

If new files exist, first check whether all changed files are code files:

```bash
node -e "
const fs = require('fs');
const path = require('path');

const result = fs.existsSync('.engram/.graphify_incremental.json') ? JSON.parse(fs.readFileSync('.engram/.graphify_incremental.json', 'utf-8')) : {};
const codeExts = new Set(['.py','.ts','.js','.go','.rs','.java','.cpp','.c','.rb','.swift','.kt','.cs','.scala','.php','.cc','.cxx','.hpp','.h','.kts','.lua','.toc']);
const newFiles = result.new_files || {};
const allChanged = Object.values(newFiles).flat();
const codeOnly = allChanged.every(f => codeExts.has(path.extname(f).toLowerCase()));
console.log('code_only:', codeOnly);
"
```

If `code_only` is True: print `[engram update] Code-only changes detected - skipping semantic extraction (no LLM needed)`, run only Step 3A (AST) on the changed files, skip Step 3B entirely (no subagents), then go straight to merge and Steps 4–8.

If `code_only` is False (any changed file is a doc/paper/image): run the full Steps 3A–3C pipeline as normal.

Then:

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');
const { buildFromJson } = require('@sentropic/engram');

// Load existing graph
const existingData = JSON.parse(fs.readFileSync('.engram/graph.json', 'utf-8'));
const GExisting = new Graph({type: 'undirected'});
for (const n of existingData.nodes) { const {id, ...a} = n; GExisting.mergeNode(id, a); }
for (const l of existingData.links) { const {source, target, ...a} = l; if (GExisting.hasNode(source) && GExisting.hasNode(target)) try { GExisting.mergeEdge(source, target, a); } catch {} }

// Load new extraction
const newExtraction = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const GNew = buildFromJson(newExtraction);

// Merge: new nodes/edges into existing graph
GNew.forEachNode((n, a) => GExisting.mergeNode(n, a));
GNew.forEachEdge((e, a, s, t) => { try { GExisting.mergeEdge(s, t, a); } catch {} });
console.log(\`Merged: ${GExisting.order} nodes, ${GExisting.size} edges\`);
" 
```

Then run Steps 4–8 on the merged graph as normal.

After Step 4, show the graph diff:

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');
const { graphDiff, buildFromJson } = require('@sentropic/engram');

const oldData = fs.existsSync('.engram/.graphify_old.json') ? JSON.parse(fs.readFileSync('.engram/.graphify_old.json', 'utf-8')) : null;
const newExtract = JSON.parse(fs.readFileSync('.engram/.graphify_extract.json', 'utf-8'));
const GNew = buildFromJson(newExtract);

if (oldData) {
    const GOld = new Graph({type: 'undirected'});
    for (const n of oldData.nodes) { const {id, ...a} = n; GOld.mergeNode(id, a); }
    for (const l of oldData.links) { const {source, target, ...a} = l; if (GOld.hasNode(source) && GOld.hasNode(target)) try { GOld.mergeEdge(source, target, a); } catch {} }
    const diff = graphDiff(GOld, GNew);
    console.log(diff.summary);
    if (diff.new_nodes && diff.new_nodes.length) {
        console.log('New nodes:', diff.new_nodes.slice(0, 5).map(n => n.label).join(', '));
    }
    if (diff.new_edges && diff.new_edges.length) {
        console.log('New edges:', diff.new_edges.length);
    }
}
"
```

Before the merge step, save the old graph: `cp .engram/graph.json .engram/.graphify_old.json`
Clean up after: `rm -f .engram/.graphify_old.json`

---

## For --cluster-only

Skip Steps 1–3. Load the existing graph from `.engram/graph.json` and re-run clustering:

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');
const { cluster, scoreAll } = require('@sentropic/engram');
const { godNodes, surprisingConnections } = require('@sentropic/engram');
const { generateReport } = require('@sentropic/engram');
const { toJson } = require('@sentropic/engram');

const data = JSON.parse(fs.readFileSync('.engram/graph.json', 'utf-8'));
const G = new Graph({type: 'undirected'});
for (const n of data.nodes) { const {id, ...a} = n; G.mergeNode(id, a); }
for (const l of data.links) { const {source, target, ...a} = l; if (G.hasNode(source) && G.hasNode(target)) try { G.mergeEdge(source, target, a); } catch {} }

const detection = {total_files: 0, total_words: 99999, needs_graph: true, warning: null,
             files: {code: [], document: [], paper: []}};
const tokens = {input: 0, output: 0};

const communities = cluster(G);
const cohesion = scoreAll(G, communities);
const gods = godNodes(G);
const surprises = surprisingConnections(G, communities);
const labels = new Map(Array.from(communities.keys(), cid => [cid, 'Community ' + cid]));

const report = generateReport(G, communities, cohesion, labels, gods, surprises, detection, tokens, '.');
fs.writeFileSync('.engram/GRAPH_REPORT.md', report);
toJson(G, communities, '.engram/graph.json');

const analysis = {
    communities: Object.fromEntries(Array.from(communities.entries(), ([k, v]) => [String(k), v])),
    cohesion: Object.fromEntries(Array.from(cohesion.entries(), ([k, v]) => [String(k), v])),
    gods,
    surprises,
};
fs.writeFileSync('.engram/.graphify_analysis.json', JSON.stringify(analysis, null, 2));
console.log(\`Re-clustered: ${communities.size} communities\`);
"
```

Then run Steps 5–9 as normal (label communities, generate viz, benchmark, clean up, report).

---

## For /engram query

Two traversal modes - choose based on the question:

| Mode | Flag | Best for |
|------|------|----------|
| BFS (default) | _(none)_ | "What is X connected to?" - broad context, nearest neighbors first |
| DFS | `--dfs` | "How does X reach Y?" - trace a specific chain or dependency path |

First check the graph exists:
```bash
node -e "
const fs = require('fs');
if (!fs.existsSync('.engram/graph.json')) {
    console.log('ERROR: No graph found. Run /engram <path> first to build the graph.');
    process.exit(1);
}
"
```
If it fails, stop and tell the user to run `/engram <path>` first.

### Step 0 - Constrained query expansion (before traversal)

`engram query` matches nodes by case-folded substring + IDF - **no stemming, no synonyms, no cross-language match**. When the question uses different vocabulary than the graph labels (user says "обработчик" / graph says "handler"; "authentication" / "Guardian"), the literal matcher returns 0 hits. Expand the query against the **actual graph vocabulary** first - never invent tokens:

```bash
node -e "
const fs = require('fs');
const g = JSON.parse(fs.readFileSync('.engram/graph.json','utf-8'));
const vocab = new Set();
for (const n of (g.nodes || [])) {
  for (const c of String(n.label || '').match(/[^\W\d_]+/gu) || []) {
    for (const p of (c.match(/[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+/g) || [c])) {
      if (p.length > 1) vocab.add(p.toLowerCase());
    }
  }
}
fs.writeFileSync('.engram/.vocab.txt', [...vocab].sort().join('\n'));
console.log('vocab: ' + vocab.size + ' tokens');
"
```

Read `.engram/.vocab.txt`, then pick **up to 12 tokens from that exact list** that match the query intent. Hard constraints:
- Use only tokens present in `.vocab.txt` - do **not** invent tokens.
- A concept with no plausible vocab token: skip it, no near-synonym from memory.
- No vocab token matches at all: output an empty list and tell the user the corpus has no relevant vocabulary; do not fabricate a search.
- Cross-language: e.g. Russian "аутентификация" - look for `auth`, `credential`, `token`, `security` **iff present** in the vocab.

Print the selection before querying (`Query expanded to (from graph vocab, N tokens): [...]`), then run `engram query` with the joined expanded tokens (keep the original question only for `save-result`).

Before deep traversal, run the compact first-hop summary and use it to choose the right graph action:

```bash
engram summary --graph .engram/graph.json
engram recommend-commits --files src/auth.ts,src/session.ts --graph .engram/graph.json
engram review-analysis --files src/auth.ts --graph .engram/graph.json
engram review-eval --cases .engram/review-cases.json --graph .engram/graph.json
```

Load `.engram/graph.json`, then:

1. Find the 1-3 nodes whose label best matches key terms in the question.
2. Run the appropriate traversal from each starting node.
3. Read the subgraph - node labels, edge relations, confidence tags, source locations.
4. Answer using **only** what the graph contains. Quote `source_location` when citing a specific fact.
5. If the graph lacks enough information, say so - do not hallucinate edges.

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');

const data = JSON.parse(fs.readFileSync('.engram/graph.json', 'utf-8'));
const G = new Graph({type: 'undirected'});
for (const n of data.nodes) { const {id, ...a} = n; G.mergeNode(id, a); }
for (const l of data.links) { const {source, target, ...a} = l; if (G.hasNode(source) && G.hasNode(target)) try { G.mergeEdge(source, target, a); } catch {} }

const question = 'QUESTION';
const mode = 'MODE';
const terms = question.split(/\s+/).filter(t => t.length > 3).map(t => t.toLowerCase());

const scored = [];
G.forEachNode((nid, ndata) => {
    const label = (ndata.label || '').toLowerCase();
    const score = terms.filter(t => label.includes(t)).length;
    if (score > 0) scored.push([score, nid]);
});
scored.sort((a, b) => b[0] - a[0]);
const startNodes = scored.slice(0, 3).map(s => s[1]);

if (!startNodes.length) { console.log('No matching nodes found for query terms:', terms); process.exit(0); }

const subgraphNodes = new Set();
const subgraphEdges = [];

if (mode === 'dfs') {
    const visited = new Set();
    const stack = [...startNodes].reverse().map(n => [n, 0]);
    while (stack.length) {
        const [node, depth] = stack.pop();
        if (visited.has(node) || depth > 6) continue;
        visited.add(node); subgraphNodes.add(node);
        G.forEachNeighbor(node, neighbor => { if (!visited.has(neighbor)) { stack.push([neighbor, depth + 1]); subgraphEdges.push([node, neighbor]); } });
    }
} else {
    let frontier = new Set(startNodes);
    startNodes.forEach(n => subgraphNodes.add(n));
    for (let i = 0; i < 3; i++) {
        const nextFrontier = new Set();
        for (const n of frontier) { G.forEachNeighbor(n, neighbor => { if (!subgraphNodes.has(neighbor)) { nextFrontier.add(neighbor); subgraphEdges.push([n, neighbor]); } }); }
        nextFrontier.forEach(n => subgraphNodes.add(n));
        frontier = nextFrontier;
    }
}

const tokenBudget = BUDGET;
const charBudget = tokenBudget * 4;
const relevance = nid => { const label = (G.getNodeAttributes(nid).label || '').toLowerCase(); return terms.filter(t => label.includes(t)).length; };
const rankedNodes = [...subgraphNodes].sort((a, b) => relevance(b) - relevance(a));

const lines = [\`Traversal: \${mode.toUpperCase()} | Start: \${JSON.stringify(startNodes.map(n => G.getNodeAttribute(n, 'label') || n))} | \${subgraphNodes.size} nodes\`];
for (const nid of rankedNodes) { const d = G.getNodeAttributes(nid); lines.push(\`  NODE \${d.label || nid} [src=\${d.source_file || ''} loc=\${d.source_location || ''}]\`); }
for (const [u, v] of subgraphEdges) { if (subgraphNodes.has(u) && subgraphNodes.has(v)) { const edge = G.hasEdge(u, v) ? G.getEdgeAttributes(G.edge(u, v)) : {}; lines.push(\`  EDGE \${G.getNodeAttribute(u, 'label') || u} --\${edge.relation || ''} [\${edge.confidence || ''}]--> \${G.getNodeAttribute(v, 'label') || v}\`); } }

let output = lines.join('
');
if (output.length > charBudget) { output = output.slice(0, charBudget) + \`
... (truncated at ~\${tokenBudget} token budget - use --budget N for more)\`; }
console.log(output);
"
```

Replace `QUESTION` with the user's actual question, `MODE` with `bfs` or `dfs`, and `BUDGET` with the token budget (default `2000`, or whatever `--budget N` specifies). Then answer based on the subgraph output above.

After writing the answer, save it back into the graph so it improves future queries:

```bash
node -e "
const { saveQueryResult } = require('@sentropic/engram');
saveQueryResult({
    question: 'QUESTION',
    answer: 'ANSWER',
    memoryDir: '.engram/memory',
    queryType: 'query',
    sourceNodes: SOURCE_NODES,  // list of node labels cited, or []
});
console.log('Query result saved to .engram/memory/');
"
```

Replace `QUESTION` with the question, `ANSWER` with your full answer text, `SOURCE_NODES` with the list of node labels you cited. This closes the feedback loop: the next `--update` will extract this Q&A as a node in the graph.

---

## For /engram path

Find the shortest path between two named concepts in the graph.

First check the graph exists:
```bash
node -e "
const fs = require('fs');
if (!fs.existsSync('.engram/graph.json')) {
    console.log('ERROR: No graph found. Run /engram <path> first to build the graph.');
    process.exit(1);
}
"
```
If it fails, stop and tell the user to run `/engram <path>` first.

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');
const { bidirectional } = require('graphology-shortest-path/unweighted');

const data = JSON.parse(fs.readFileSync('.engram/graph.json', 'utf-8'));
const G = new Graph({type: 'undirected'});
for (const n of data.nodes) { const {id, ...a} = n; G.mergeNode(id, a); }
for (const l of data.links) { const {source, target, ...a} = l; if (G.hasNode(source) && G.hasNode(target)) try { G.mergeEdge(source, target, a); } catch {} }

const aTerm = 'NODE_A';
const bTerm = 'NODE_B';

function findNode(term) {
    term = term.toLowerCase();
    const scored = [];
    G.forEachNode((n, a) => {
        const label = (a.label || '').toLowerCase();
        const score = term.split(/\s+/).filter(w => label.includes(w)).length;
        if (score > 0) scored.push([score, n]);
    });
    scored.sort((a, b) => b[0] - a[0]);
    return scored.length && scored[0][0] > 0 ? scored[0][1] : null;
}

const src = findNode(aTerm);
const tgt = findNode(bTerm);

if (!src || !tgt) {
    console.log(\`Could not find nodes matching: '${aTerm}' or '${bTerm}'\`);
    process.exit(0);
}

const path = bidirectional(G, src, tgt);
if (!path) {
    console.log(\`No path found between '${aTerm}' and '${bTerm}'\`);
} else {
    console.log(\`Shortest path (${path.length - 1} hops):\`);
    for (let i = 0; i < path.length; i++) {
        const nid = path[i];
        const label = G.getNodeAttribute(nid, 'label') || nid;
        if (i < path.length - 1) {
            const edgeKey = G.edge(nid, path[i + 1]);
            const edge = edgeKey ? G.getEdgeAttributes(edgeKey) : {};
            console.log(\`  ${label} --${edge.relation || ''}--> [${edge.confidence || ''}]\`);
        } else {
            console.log(\`  ${label}\`);
        }
    }
}
"
```

Replace `NODE_A` and `NODE_B` with the actual concept names from the user. Then explain the path in plain language - what each hop means, why it's significant.

After writing the explanation, save it back:

```bash
node -e "
const { saveQueryResult } = require('@sentropic/engram');
saveQueryResult({
    question: 'Path from NODE_A to NODE_B',
    answer: 'ANSWER',
    memoryDir: '.engram/memory',
    queryType: 'path_query',
    sourceNodes: PATH_NODES,  // list of node labels on the path
});
console.log('Path result saved to .engram/memory/');
"
```

---

## For /engram explain

Give a plain-language explanation of a single node - everything connected to it.

First check the graph exists:
```bash
node -e "
const fs = require('fs');
if (!fs.existsSync('.engram/graph.json')) {
    console.log('ERROR: No graph found. Run /engram <path> first to build the graph.');
    process.exit(1);
}
"
```
If it fails, stop and tell the user to run `/engram <path>` first.

```bash
node -e "
const fs = require('fs');
const Graph = require('graphology');

const data = JSON.parse(fs.readFileSync('.engram/graph.json', 'utf-8'));
const G = new Graph({type: 'undirected'});
for (const n of data.nodes) { const {id, ...a} = n; G.mergeNode(id, a); }
for (const l of data.links) { const {source, target, ...a} = l; if (G.hasNode(source) && G.hasNode(target)) try { G.mergeEdge(source, target, a); } catch {} }

const term = 'NODE_NAME';
const termLower = term.toLowerCase();

const scored = [];
G.forEachNode((n, a) => { const label = (a.label || '').toLowerCase(); const score = termLower.split(/\s+/).filter(w => label.includes(w)).length; if (score > 0) scored.push([score, n]); });
scored.sort((a, b) => b[0] - a[0]);
if (!scored.length || scored[0][0] === 0) { console.log(\`No node matching '\${term}'\`); process.exit(0); }

const nid = scored[0][1];
const dataN = G.getNodeAttributes(nid);
console.log(\`NODE: \${dataN.label || nid}\`);
console.log(\`  source: \${dataN.source_file || 'unknown'}\`);
console.log(\`  type: \${dataN.file_type || 'unknown'}\`);
console.log(\`  degree: \${G.degree(nid)}\`);
console.log();
console.log('CONNECTIONS:');
G.forEachNeighbor(nid, (neighbor) => {
    const ek = G.edge(nid, neighbor); const edge = ek ? G.getEdgeAttributes(ek) : {};
    const nlabel = G.getNodeAttribute(neighbor, 'label') || neighbor;
    console.log(\`  --\${edge.relation || ''}--> \${nlabel} [\${edge.confidence || ''}] (\${G.getNodeAttribute(neighbor, 'source_file') || ''})\`);
});
"
```

Replace `NODE_NAME` with the concept the user asked about. Then write a 3-5 sentence explanation of what this node is, what it connects to, and why those connections are significant. Use the source locations as citations.

After writing the explanation, save it back:

```bash
node -e "
const { saveQueryResult } = require('@sentropic/engram');
saveQueryResult({
    question: 'Explain NODE_NAME',
    answer: 'ANSWER',
    memoryDir: '.engram/memory',
    queryType: 'explain',
    sourceNodes: ['NODE_NAME'],
});
console.log('Explanation saved to .engram/memory/');
"
```

---

## For /engram add

Fetch a URL and add it to the corpus, then update the graph.

```bash
node -e "
const { ingest } = require('@sentropic/engram');
try {
    const out = ingest('URL', './raw', {author: 'AUTHOR', contributor: 'CONTRIBUTOR'});
    console.log(\`Saved to ${out}\`);
} catch (e) {
    console.error(\`error: ${e.message}\`);
    process.exit(1);
}
"
```

Replace `URL` with the actual URL, `AUTHOR` with the user's name if provided, `CONTRIBUTOR` likewise. If the command exits with an error, tell the user what went wrong - do not silently continue. After a successful save, automatically run the `--update` pipeline on `./raw` to merge the new file into the existing graph.

Supported URL types (auto-detected):
- Twitter/X → fetched via oEmbed, saved as `.md` with tweet text and author
- arXiv → abstract + metadata saved as `.md`  
- YouTube / video URLs → audio downloaded locally via `yt-dlp`; transcript generated on the next build/update (requires local `yt-dlp`, `ffmpeg`, and `faster-whisper-ts`)
- PDF → downloaded as `.pdf`
- Images (.png/.jpg/.webp) → downloaded, vision extracts on next run; if they are PDF-extracted artifacts, decode diagrams/tables/embedded text with assistant vision or a configured delegated OCR/vision model while preserving PDF provenance
- Any webpage → converted to markdown via html2text

---

## For --watch

Start a background watcher that monitors a folder and auto-updates the graph when files change.

```bash
npx engram watch INPUT_PATH --debounce 3
```

Replace INPUT_PATH with the folder to watch. Behavior depends on what changed:

- **Code files only (.py, .ts, .go, etc.):** re-runs AST extraction + rebuild + cluster immediately, no LLM needed. `graph.json` and `GRAPH_REPORT.md` are updated automatically.
- **Docs, papers, or images:** writes a `.engram/needs_update` flag and prints a notification to run `/engram --update` (LLM semantic re-extraction required).

Debounce (default 3s): waits until file activity stops before triggering, so a wave of parallel agent writes doesn't trigger a rebuild per file.

Press Ctrl+C to stop.

For agentic workflows: run `--watch` in a background terminal. Code changes from agent waves are picked up automatically between waves. If agents are also writing docs or notes, you'll need a manual `/engram --update` after those waves.

---

## For git commit hook

Install a post-commit hook that auto-rebuilds the graph after every commit. No background process needed - triggers once per commit, works with any editor.

```bash
engram hook install    # install
engram hook uninstall  # remove
engram hook status     # check
```

After every `git commit`, the hook detects which code files changed (via `git diff HEAD~1`), re-runs AST extraction on those files, and rebuilds `graph.json` and `GRAPH_REPORT.md`. Doc/image changes are ignored by the hook - run `/engram --update` manually for those.

If a post-commit hook already exists, Engram appends to it rather than replacing it.

---

## For native CLAUDE.md integration

Run once per project to make Engram always-on in Claude Code sessions:

```bash
engram claude install
```

This writes a `## engram` section to the local `CLAUDE.md` that instructs Claude to check the graph before answering codebase questions and rebuild it after code changes. No manual `/engram` needed in future sessions.

```bash
engram claude uninstall  # remove the section
```

---

## Verifiability Rules

- Never invent an edge. If unsure, use AMBIGUOUS.
- Never skip the corpus check warning.
- Always show token cost in the report.
- Never hide cohesion scores behind symbols - show the raw number.
- The static Ontology Studio scales to large graphs (WebGL + pre-computed positions) - export it for graphs of any size; no node-count cap.

## Configured Project Profiles

The profile activation rule is explicit: use this branch only when `graphify.yaml`, `graphify.yml`, `.engram/config.yaml`, or `.engram/config.yml` exists, or the invocation includes `--config` or `--profile`. If none is active, fallback to the existing non-profile workflow.

Configured profile workflow:
1. Keep the TypeScript runtime proof in `.engram/.graphify_runtime.json`; it must contain `"runtime": "typescript"`.
2. Run `project-config` to normalize config/profile artifacts.
3. Run the `configured-dataprep` runtime command to produce `.engram/profile/profile-state.json`, semantic detection, and registry extraction.
4. Run the `profile-prompt` runtime command and use that prompt for assistant semantic extraction.
5. Run base extraction validation, then the `profile-validate-extraction` runtime command.
6. Merge `.engram/profile/registry-extraction.json` with AST and semantic extraction, then finalize through the existing build/report/export runtime commands.
7. Run the `profile-report` runtime command to write `.engram/profile/profile-report.md`.
8. If ontology discovery is requested, run `profile-discovery-sample`, use its prompt to produce `.engram/ontology/discovery/proposals.json`, then run `profile-discovery-diff`; present the diff/report to the user and wait for approval before any apply step.
9. If `dataprep.image_analysis.enabled` is true, use `image-calibration-samples` and `image-calibration-replay` for calibration. The assistant may propose labels or rule changes, but TypeScript replay owns acceptance.
10. For batch image analysis, use `image-batch-export` and `image-batch-import`. A deep-pass export is allowed only when project-owned routing rules declare `decision: accept_matrix`; do not make production route decisions in the assistant.
11. If the profile declares `outputs.ontology.enabled: true`, run `ontology-output` to compile `.engram/ontology/` after validated extraction exists.

## Ontology Lifecycle Patches

Use ontology lifecycle commands only when profile artifacts and `.engram/ontology/` outputs already exist. Review decisions are patches against project-owned sources, not direct graph mutations. Assistants may propose patches, but must validate before dry-run and dry-run before write.

- Validate with `ontology-patch-validate --profile-state .engram/profile/profile-state.json --patch patch.json`.
- Preview with `ontology-patch-apply --profile-state .engram/profile/profile-state.json --patch patch.json --dry-run`.
- Write with `ontology-patch-apply --profile-state .engram/profile/profile-state.json --patch patch.json --write` only after explicit user approval.
- Always warn if the Git worktree is dirty before proposing a write apply.
- Agents must not edit `.engram/graph.json` or derived `.engram/ontology/*.json` directly.
- The default MCP server stays read-only; mutation tools require explicit `engram ontology serve --config graphify.yaml --write`.
- Use the Public Domain Mystery Sagas repo as an external UAT and UI-mock corpus only; do not add its real corpus as Engram package fixtures.

Do not add embeddings, databases, a resident LLM backend, or a forked OCR/PDF pipeline for this branch.

## Lifecycle State

- Runtime state lives under `.engram/`; do not create legacy visible state directories.
- If `.engram/graph.json` is missing but legacy `graphify-out/graph.json` exists, run `engram migrate-state --dry-run` first. If it reports tracked legacy artifacts, ask before using the recommended `git mv -f graphify-out .engram` and commit message; do not auto-stage or auto-commit.
- For architecture or codebase questions, when `.engram/graph.json` exists, first run `engram query "<question>"` (or `engram path "<A>" "<B>"` / `engram explain "<concept>"`); these return a scoped subgraph, usually much smaller than `GRAPH_REPORT.md` or raw grep output.
- Use `.engram/wiki/index.md` first when present; read `.engram/GRAPH_REPORT.md` only for broad architecture review or when `query` / `path` / `explain` do not surface enough context.
- If `.engram/needs_update` exists or `.engram/branch.json` has `"stale": true`, tell the user the graph is stale and run the platform Engram command with `--update` before relying on semantic results.
- Before proposing or committing `.engram` artifacts, run `engram portable-check .engram`; commit-safe graph artifacts must use repo-relative paths, and never commit `.engram/branch.json`, `.engram/worktree.json`, `.engram/needs_update`, or `.engram/cache/`. If a repo already tracks any of them, first add them to `.gitignore`, then propose `git rm --cached .engram/branch.json .engram/worktree.json .engram/needs_update` and `git rm -r --cached .engram/cache`; never mutate git state without asking.
- An existing `.graphify/` state dir is still read as a legacy fallback; new writes go to `.engram/`.
- Git hooks may mark stale state after branch switches, merges, and rewrites. Never delete `.engram/` automatically; use `engram state prune` only as a non-destructive cleanup preview.

Commit recommendation workflow: `engram recommend-commits` is advisory-only. It may suggest groups and commit messages, but the user remains the actor; do not auto-stage, auto-commit, or mutate branches.

CRG review workflow: `engram minimal-context` is the first review call. Keep graph review context within `<=5 graph tool calls` and `<=800` graph-context tokens. If `.engram/needs_update` exists or `.engram/branch.json` has `stale=true`, warn and update before trusting semantic review output. Then follow only the compact route: `engram detect-changes` for risk, `engram affected-flows` for flow impact, and `engram review-context` for snippets or radius detail. If `.engram/flows.json` is missing and flows are needed, run `engram flows build` first. Explicit `--files`, `--base`, `--head`, or `--staged` inputs override unrelated dirty worktree noise; mention dirty worktrees as a warning and never mutate git state.

Review analysis workflow: `engram review-analysis` adds blast radius, bridge nodes, test-gap hints, impacted communities, and multimodal/doc safety. `engram review-eval` is the deterministic evaluation harness for token savings, impacted-file recall, review summary precision, and multimodal regression safety.
